require('dotenv').config();
const express = require('express');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

app.post('/create-checkout-session', async (req, res) => {
  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['ideal'],
      line_items: req.body.items.map(item => ({
        price_data: {
          currency: 'eur',
          product_data: { name: item.name },
          unit_amount: item.price
        },
        quantity: item.quantity || 1
      })),
      mode: 'payment',
      success_url: 'http://localhost:3000/success',
      cancel_url: 'http://localhost:3000/cancel'
    });

    res.json({ url: session.url });
  } catch (error) {
    console.error('Stripe fout:', error);
    res.status(500).json({ error: 'Interne serverfout' });
  }
});

const PORT = 4242;
app.listen(PORT, () => console.log(`✅ Server draait op http://localhost:${PORT}`));
