import React, { useContext } from 'react';
import { CartContext } from '../context/CartContext';

const CartPage = () => {
  const { cartItems, removeFromCart, clearCart } = useContext(CartContext);

  const handleCheckout = async () => {
    try {
      const response = await fetch('http://localhost:4242/create-checkout-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: cartItems.map(item => ({
            name: item.name,
            price: item.price * 1, // prijs in centen
            quantity: item.quantity || 1
          }))
        }),
      });

      const data = await response.json();

      if (data.url) {
        clearCart();
        window.location.href = data.url;
      } else {
        alert('Er ging iets mis met de betaling.');
      }
    } catch (error) {
      console.error('Checkout fout:', error);
      alert('Checkout mislukt.');
    }
  };

  const total = cartItems.reduce((acc, item) => acc + item.price * (item.quantity || 1), 0);

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Winkelmandje</h2>
      {cartItems.length === 0 ? (
        <p>Je winkelmandje is leeg.</p>
      ) : (
        <>
          <ul className="space-y-4">
            {cartItems.map((item, idx) => (
              <li key={idx} className="border p-4 rounded flex justify-between">
                <div>
                  <p className="font-semibold">{item.name}</p>
                  <p>€{(item.price / 100).toFixed(2)}</p>
                </div>
                <button
                  onClick={() => removeFromCart(item.id)}
                  className="text-red-500 hover:underline"
                >
                  Verwijder
                </button>
              </li>
            ))}
          </ul>
          <div className="mt-6 text-right">
            <p className="text-lg font-semibold mb-4">Totaal: €{(total / 100).toFixed(2)}</p>
            <button
              onClick={handleCheckout}
              className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700"
            >
              Betaal met iDEAL
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default CartPage;
